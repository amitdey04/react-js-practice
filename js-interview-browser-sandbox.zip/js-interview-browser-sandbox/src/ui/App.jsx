import React, { useMemo, useState } from 'react'
import demos from '../register'

export default function App(){
  const [active, setActive] = useState(Object.keys(demos)[0])
  const [output, setOutput] = useState('')
  const Demo = useMemo(()=>demos[active], [active])
  const run = async () => {
    let buf = []
    const log = (...args) => { buf.push(args.map(x => typeof x==='object' ? JSON.stringify(x) : String(x)).join(' ')) }
    try {
      const result = await Demo.run(log)
      if (result !== undefined) log('return:', result)
    } catch (e) {
      log('ERROR:', e?.message || String(e))
    }
    setOutput(buf.join('\n'))
  }
  return (
    <div style={{display:'grid', gridTemplateColumns:'260px 1fr', height:'100vh', fontFamily:'Inter, system-ui, sans-serif'}}>
      <aside style={{borderRight:'1px solid #ddd', padding:'12px', overflow:'auto'}}>
        <h3>Browser Demos</h3>
        <p style={{fontSize:12, color:'#666'}}>Click a demo, then run it.</p>
        <ul style={{listStyle:'none', padding:0}}>
          {Object.entries(demos).map(([k, v]) => (
            <li key={k}>
              <button onClick={()=>setActive(k)} style={{display:'block', width:'100%', textAlign:'left', padding:'8px', margin:'4px 0', borderRadius:8, border: k===active ? '1px solid #333' : '1px solid #ccc', background: k===active ? '#f1f5f9' : 'white' }}>
                <div style={{fontWeight:600}}>{v.meta.title}</div>
                <div style={{fontSize:12, color:'#666'}}>{v.meta.tags.join(' • ')}</div>
              </button>
            </li>
          ))}
        </ul>
        <button onClick={run} style={{marginTop:12, padding:'10px 14px', borderRadius:10, border:'1px solid #111'}}>▶ Run</button>
      </aside>
      <main style={{padding:'16px'}}>
        <h2 style={{marginTop:0}}>{demos[active].meta.title}</h2>
        <pre style={{background:'#0b1021', color:'#cbe2ff', padding:'16px', borderRadius:12, minHeight: '60vh', overflow:'auto'}}>{output || 'Output will appear here...'}</pre>
        <p style={{color:'#666'}}>Gotcha: {demos[active].meta.gotcha}</p>
      </main>
    </div>
  )
}
