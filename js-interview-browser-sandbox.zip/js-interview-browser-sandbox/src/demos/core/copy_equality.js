
export default {
  meta: { title: 'Shallow vs deep copy', tags: ['spread','structuredClone'], gotcha: 'Spread is shallow; structuredClone is deep.' },
  async run(log){
    const a={u:{n:1}}; const b={...a}; b.u.n=2;
    log('a.u.n', a.u.n);
    const c=structuredClone(a); c.u.n=5;
    log('a.u.n', a.u.n, 'c.u.n', c.u.n);
  }
}