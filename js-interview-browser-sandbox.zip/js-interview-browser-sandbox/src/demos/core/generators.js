
export default {
  meta: { title: 'Generators & async iterables', tags: ['iterators','async'], gotcha: 'Use for await...of for async generators.' },
  async run(log){
    function* id(){ let i=0; while(i<3) yield i++; }
    const g=id(); log(g.next().value, g.next().value);
    async function* twice(arr){ for (const x of arr){ await new Promise(r=>setTimeout(r,20)); yield x*2; } }
    for await (const v of twice([1,2,3])) log(v);
  }
}