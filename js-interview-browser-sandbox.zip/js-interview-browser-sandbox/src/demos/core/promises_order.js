
export default {
  meta: { title: 'Event loop order', tags: ['promises','microtasks'], gotcha: 'Microtasks run before timers.' },
  async run(log){
    log(1);
    setTimeout(()=>log(2));
    Promise.resolve().then(()=>log(3));
    log(4);
    await Promise.resolve();
    await new Promise(r=>setTimeout(r,0));
    log('Expected: 1,4,3,2');
  }
}