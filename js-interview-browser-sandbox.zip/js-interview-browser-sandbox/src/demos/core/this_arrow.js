
export default {
  meta: { title: 'this vs arrow', tags: ['this','arrow'], gotcha: 'Arrow functions capture lexical this; methods need function syntax.' },
  async run(log){
    const obj = { x:1, m1(){ return this.x }, m2: () => this?.x };
    log(obj.m1()); // 1
    log(obj.m2()); // undefined in modules
  }
}