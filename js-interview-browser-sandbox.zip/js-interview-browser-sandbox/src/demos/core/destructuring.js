
export default {
  meta: { title: 'Destructuring defaults', tags: ['destructuring'], gotcha: 'Default nested objects to avoid undefined errors.' },
  async run(log){
    const user={id:1, name:'R', meta:{role:'admin'}};
    const { meta:{ role } = { role:'guest' } } = user;
    log(role);
  }
}