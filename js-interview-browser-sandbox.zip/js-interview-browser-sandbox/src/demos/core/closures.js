
export default {
  meta: { title: 'Closures: counter factory', tags: ['scope','closures'], gotcha: 'Each factory call has its own closed-over state.' },
  async run(log){
    function makeCounter(start=0){ let c=start; return ()=>++c; }
    const c1 = makeCounter(10); log(c1(), c1());
    const c2 = makeCounter(); log(c2(), c2());
  }
}