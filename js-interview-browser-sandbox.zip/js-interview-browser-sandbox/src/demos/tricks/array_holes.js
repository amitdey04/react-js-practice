
export default {
  meta: { title: 'Array holes vs Array.from', tags: ['arrays'], gotcha: 'new Array(3).map(...) does not iterate holes.' },
  async run(log){
    log(JSON.stringify(new Array(3).map((_,i)=>i)));
    log(JSON.stringify(Array.from({length:3},(_,i)=>i)));
  }
}