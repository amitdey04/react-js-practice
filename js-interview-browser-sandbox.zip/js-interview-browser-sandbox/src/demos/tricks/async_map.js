
export default {
  meta: { title: 'Array.map(async) returns promises', tags: ['promises','map'], gotcha: 'map(async) yields Promise[], use Promise.all.' },
  async run(log){
    const out=[1,2,3].map(async x=>x*2);
    log(Array.isArray(out), 'isPromise', typeof out[0].then==='function');
    log((await Promise.all(out)).join(','));
  }
}