
export default {
  meta: { title: 'Optional chaining + nullish coalescing', tags: ['??','?.'], gotcha: 'Use ?? so 0 and "" don’t get replaced.' },
  async run(log){
    const config={server:{port:0}};
    const portOr = config.server?.port ?? 3000;
    const portBad = config.server?.port || 3000;
    log(JSON.stringify({portOr, portBad}));
  }
}